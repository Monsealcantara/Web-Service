from spyne import Application, rpc, ServiceBase, Integer
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication

# Definición de la clase de servicio 'CalculatorService' que hereda de 'ServiceBase'.
# Esta clase representa un servicio SOAP básico que permite realizar operaciones de suma.
class CalculatorService(ServiceBase):
    # Define un método de servicio llamado 'add' que puede ser llamado por clientes SOAP.
    # Este método toma dos enteros como entrada y devuelve su suma.
    @rpc(Integer, Integer, _returns=Integer)
    def add(ctx, a, b):
        # El método recibe tres argumentos:
        # - ctx: El contexto de la llamada RPC (obligatorio en Spyne, aunque no se usa aquí).
        # - a: Primer número entero que se sumará.
        # - b: Segundo número entero que se sumará.
        return a + b  # Retorna la suma de 'a' y 'b'.

# Creación de la aplicación SOAP que alojará el servicio de la calculadora.
# - 'CalculatorService': La clase de servicio que se registra en la aplicación.
# - 'tns': El espacio de nombres (namespace) del servicio, definido aquí como 'spyne.examples.calculator'.
# - 'in_protocol': Protocolo de entrada que usa SOAP 1.1 con validación 'lxml' (librería de análisis XML).
# - 'out_protocol': Protocolo de salida, también definido como SOAP 1.1.
application = Application([CalculatorService],
    tns='spyne.examples.calculator',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

# Convierte la aplicación en un objeto WSGI, que puede ser servido por un servidor WSGI.
wsgi_app = WsgiApplication(application)

# Punto de entrada principal para ejecutar el servidor.
# Este bloque se ejecuta solo si el script se ejecuta directamente, no si se importa como módulo.
if __name__ == '__main__':
    # Importa un servidor WSGI básico de 'wsgiref'.
    from wsgiref.simple_server import make_server
    
    # Configura el servidor en la dirección '127.0.0.1' y el puerto '8000', sirviendo 'wsgi_app'.
    server = make_server('127.0.0.1', 8000, wsgi_app)
    
    # Imprime un mensaje indicando que el servidor está en ejecución.
    print("Serving on port 8000...")
    
    # Ejecuta el servidor en un bucle infinito, esperando y respondiendo a las solicitudes.
    server.serve_forever()
