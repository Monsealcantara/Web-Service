from spyne import Application, rpc, ServiceBase, Integer, Unicode
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication

# Definición de la clase de servicio 'HelloWorldService' que hereda de 'ServiceBase'.
class HelloWorldService(ServiceBase):
    # Define un método de servicio llamado 'say_hello' que puede ser llamado por clientes SOAP.
    # Este método toma dos parámetros:
    # - 'name': Un string (Unicode) que representa el nombre que se incluirá en el saludo.
    # - 'times': Un entero (Integer) que indica cuántas veces se debe repetir el nombre.
    # El método devuelve un string (Unicode) que es el saludo con el nombre repetido 'times' veces.
    @rpc(Unicode, Integer, _returns=Unicode)
    def say_hello(ctx, name, times):
        return f"Hello, {name * times}"

    # Método estático llamado 'say_hello_direct' que es una versión independiente de 'say_hello'.
    # Este método no requiere el contexto 'ctx' y se puede invocar directamente, lo cual es útil para pruebas unitarias.
    # - 'name': Un string que representa el nombre que se incluirá en el saludo.
    # - 'times': Un entero que indica cuántas veces se debe repetir el nombre.
    # Devuelve el saludo con el nombre repetido 'times' veces.
    @staticmethod
    def say_hello_direct(name, times):
        return f"Hello, {name * times}"

# Creación de la aplicación SOAP.
# - 'HelloWorldService': La clase de servicio que se registra en la aplicación.
# - 'tns': El espacio de nombres (namespace) del servicio, definido aquí como 'spyne.examples.hello'.
# - 'in_protocol': Protocolo de entrada que usa SOAP 1.1 con validación 'lxml' (librería de análisis XML).
# - 'out_protocol': Protocolo de salida, también definido como SOAP 1.1.
application = Application([HelloWorldService],
                          tns='spyne.examples.hello',
                          in_protocol=Soap11(validator='lxml'),
                          out_protocol=Soap11()
                         )

# Convierte la aplicación en un objeto WSGI, que puede ser servido por un servidor WSGI.
wsgi_app = WsgiApplication(application)

# Punto de entrada principal para ejecutar el servidor.
# Este bloque se ejecuta solo si el script se ejecuta directamente, no si se importa como módulo.
if __name__ == '__main__':
    # Importa un servidor WSGI básico de 'wsgiref'.
    from wsgiref.simple_server import make_server
    # Configura el servidor en la dirección '127.0.0.1' y el puerto '8000', sirviendo 'wsgi_app'.
    server = make_server('127.0.0.1', 8000, wsgi_app)
    print("Serving on port 8000...")
    # Ejecuta el servidor en un bucle infinito, esperando y respondiendo a las solicitudes.
    server.serve_forever()




# from spyne import Application, rpc, ServiceBase, Integer, Unicode
# from spyne.protocol.soap import Soap11
# from spyne.server.wsgi import WsgiApplication

# class HelloWorldService(ServiceBase):
#     @rpc(Unicode, Integer, _returns=Unicode)
#     def say_hello(ctx, name, times):
#         return f"Hello, {name * times}"

# application = Application([HelloWorldService],
# tns='spyne.examples.hello',
# in_protocol=Soap11(validator='lxml'),
# out_protocol=Soap11()
# )
# wsgi_app = WsgiApplication(application)
# if __name__ == '__main__':
#     from wsgiref.simple_server import make_server
#     server = make_server('127.0.0.1', 8000, wsgi_app)
#     print("Serving on port 8000...")
#     server.serve_forever()