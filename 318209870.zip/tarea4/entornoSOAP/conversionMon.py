from spyne import Application, rpc, ServiceBase, Integer, Float, Unicode
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication

# Definición de la clase de servicio 'CurrencyConverterService' que hereda de 'ServiceBase'.
# Esta clase representa un servicio SOAP para convertir divisas.
class CurrencyConverterService(ServiceBase):
    # Define un método de servicio llamado 'convert' que puede ser llamado por clientes SOAP.
    # Este método toma tres parámetros:
    # - 'amount' (Float): La cantidad de dinero a convertir.
    # - 'from_currency' (Unicode): La moneda de origen.
    # - 'to_currency' (Unicode): La moneda de destino.
    # Devuelve un valor Float que es la cantidad convertida a la moneda de destino.
    @rpc(Float, Unicode, Unicode, _returns=Float)
    def convert(ctx, amount, from_currency, to_currency):
        # Diccionario de tasas de cambio con valores de ejemplo.
        # En un servicio real, estas tasas podrían obtenerse de una API externa.
        rates = {'USD': 1.0, 'EUR': 0.85, 'MXN': 20.0}
        
        # Realiza la conversión usando las tasas de cambio.
        # Calcula la cantidad convertida al multiplicar 'amount' por la tasa de la moneda
        # de destino y dividir por la tasa de la moneda de origen.
        return amount * rates[to_currency] / rates[from_currency]

# Creación de la aplicación SOAP que albergará el servicio.
# - 'CurrencyConverterService': La clase de servicio que se registra en la aplicación.
# - 'tns': El espacio de nombres (namespace) del servicio, definido aquí como 'spyne.examples.currency_converter'.
# - 'in_protocol': Protocolo de entrada que usa SOAP 1.1 con validación 'lxml' (librería de análisis XML).
# - 'out_protocol': Protocolo de salida, también definido como SOAP 1.1.
application = Application([CurrencyConverterService],
    tns='spyne.examples.currency_converter',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

# Convierte la aplicación en un objeto WSGI, que puede ser servido por un servidor WSGI.
wsgi_app = WsgiApplication(application)

# Punto de entrada principal para ejecutar el servidor.
# Este bloque se ejecuta solo si el script se ejecuta directamente, no si se importa como módulo.
if __name__ == '__main__':
    # Importa un servidor WSGI básico de 'wsgiref'.
    from wsgiref.simple_server import make_server
    
    # Configura el servidor en la dirección '127.0.0.1' y el puerto '8000', sirviendo 'wsgi_app'.
    server = make_server('127.0.0.1', 8000, wsgi_app)
    
    # Imprime un mensaje indicando que el servidor está en ejecución.
    print("Serving on port 8000...")
    
    # Ejecuta el servidor en un bucle infinito, esperando y respondiendo a las solicitudes.
    server.serve_forever()
