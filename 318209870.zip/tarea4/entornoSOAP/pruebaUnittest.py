import unittest
from hello_world_service import HelloWorldService

# Definición de la clase de prueba 'TestHelloWorldService', que hereda de 'unittest.TestCase'.
# Esta clase contiene pruebas unitarias para el servicio 'HelloWorldService'.
class TestHelloWorldService(unittest.TestCase):
    # Método de prueba que verifica el funcionamiento del método 'say_hello_direct'.
    def test_say_hello(self):
        # Llama al método 'say_hello_direct' de 'HelloWorldService' con los argumentos 'World' y 3.
        response = HelloWorldService.say_hello_direct('World', 3)
        
        # Imprime un mensaje que indica que se está probando el método con parámetros específicos.
        print("Probando el método say_hello_direct con los parámetros: 'World', 3")
        
        # Verifica que la respuesta sea igual al valor esperado, 'Hello, WorldWorldWorld'.
        # Si no es así, se muestra el mensaje de error personalizado.
        self.assertEqual(response, 'Hello, WorldWorldWorld', "El método say_hello_direct no generó la salida esperada.")
        
        # Imprime un mensaje de éxito si la prueba pasa.
        print("Prueba exitosa: La salida fue la esperada.")

# Punto de entrada principal para ejecutar las pruebas.
# Este bloque se ejecuta solo si el script se ejecuta directamente, no si se importa como módulo.
if __name__ == '__main__':
    unittest.main()  # Ejecuta todas las pruebas definidas en la clase 'TestHelloWorldService'.


# import unittest
# from hello_world_service import HelloWorldService

# class TestHelloWorldService(unittest.TestCase):
#     def test_say_hello(self):
#         service= HelloWorldService()
#         response = service.say_hello('World', 3)
#         self.assertEqual(response, 'Hello, WorldWorldWorld')

# if __name__== '__main__':
#     unittest.main()